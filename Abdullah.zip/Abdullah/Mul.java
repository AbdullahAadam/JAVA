import java.util.*;
import java.util.Scanner;
class Mul
{
	static void run()
	{
		try{
		for(int i=1;i<=10; i++)
		{
			int an=i*5;
			System.out.println(i+"* 5"+"="+an);
			Thread.sleep(100);
		}
		}
		catch(InterruptedException e)
		{
			System.out.println("sleeping");
		}
	
	
	
	}
	public static void main(String args[])
	{
		//Scanner oj=new Scanner(System.in);
		Mul oj=new Mul();
		//System.out.println("Enter what your  tables to print");
		//int x=oj.nextInt();
		//S/ystem.out.println("Enter who many wants to print");
		//int y=oj.nextInt();
		long stime=System.nanoTime();
		System.out.println("Strating Time "+stime);
		oj.run();
		oj.run();
		long etime=System.nanoTime();
		System.out.println("Ending Time"+etime);
		long time=etime-stime;
		System.out.println("Time Taken"+time);
	}

}
