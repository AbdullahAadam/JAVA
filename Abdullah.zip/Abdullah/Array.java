import java.util.Scanner;
class Array
{
	static void AddArray( int a[], int val)
	{
		for(int i=0; i<5;i++)
		{
			a[i]=a[i]+val;
		}	
	
	
	
	}
	public static void main(String args[])
	{
		Scanner obj=new Scanner(System.in);
		int a[]={10,20,30,40,50};
		System.out.println("Element of Array are here....");
		for(int i=0; i<5;i++)
		{
		
			System.out.println(i+")"+" "+a[i]);
		
		}
		System.out.println("Enter the Values to modify the Array");
		int cl=obj.nextInt();
		AddArray(a,cl);
		System.out.println("ALL Element of Array is Modified....");
		for(int i=0; i<5;i++)
		{
			System.out.println(a[i]);
		}
		
		/*<----------+5 ONLY ONE ELEMNT----->
		System.out.println("Select which Element u want to modify and Enter only Index number ");
		int cl=obj.nextInt();
		
		a[cl]=a[cl]+5;
		for(int i=0; i<5;i++)
		{
		
			System.out.println(i+")"+" "+a[i]);
		
		}*/
		
		/*System.out.println("ALL Element of Array is Modified....");
		for(int i=0; i<5;i++)
		{
			a[i]=a[i]+5;
			System.out.println(a[i]);
		
		}*/
	
		/* <----Odd and Even Array Modified------>
		System.out.println("ALL Element of Array is Modified....");
		for(int i=0; i<5;i++)
		{
			if(i%2==0)
			{
				a[i]=a[i]+10;
			
			}
			else
			{
				a[i]=a[i]+5;
			}
			System.out.println(a[i]);
		
		}*/
	
	
	
	
	}







}
