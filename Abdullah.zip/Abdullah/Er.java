import java.util.Scanner;
class Er
{
 	public static void main(String args[])
 	{
 		Scanner oj=new Scanner(System.in);
 		int a=10;
 		int b=0;
 		//System.out.println("Enter the 1st value: " );
 		//a=oj.nextInt();
 		//System.out.println("Enter the 2st value: " );
 		//int b=oj.nextInt();
 		try
 		{
 			int res;
 			res=a/b;
 			System.out.println("The Result is: "+res);
 		}
 		
 		catch(ArithmeticException e)
 		{
 			System.out.println("Zero division Error.."); 		
 		}
 		catch(Exception e)
 		{
 			System.out.println("COMMM Error");
 		}	
	}
}
