class Ran
{
	public static void main(String args[])
	{
		String name="Abdullah";
		int min=1;
		int max=20;
		double val=23.55;
		for(int i=1; i<=20; i++)
		{
			//System.out.println(name+Math.random());
			//System.out.println(Math.round(Math.random()*10));
			//System.out.println(name+Math.round(Math.random()*20));
			//System.out.println(Math.random());
			System.out.println(Math.floor(val));
		
		
		
		
		}	
	
	
	
	
	
	
	
	
	}







}
