import java.util.Scanner;
class ArrayCheck
{
	/*public static void main(String args[])
	{
		Scanner oj=new Scanner(System.in);
		Boolean con=false;
		String array[]={"Velu","Raj","Kumar"};
		System.out.println("My Friend List:  ");
		for(int i=0; i<array.length; i++)
		{
			System.out.println(array[i]);
		}
		System.out.println("Enter your name to check your friend or not");
		String find=oj.nextLine();
		String bup=find;
		//System.out.println(find.toUpperCase());
		find=find.toUpperCase();
		for(int i=0; i<array.length; i++)
		{
			array[i]=array[i].toUpperCase();
			if(array[i].equals(find))
			{
				con=true;
				//System.out.println(array[i]);
				break;
			}
			
			//con=false;
		}
		if(con)
		{
			System.out.println(bup+" Your my friend ");
		}
		else
		{
		
			System.out.println(bup+" Your not my friend list");
		}
	}*/
	static void display(String x[])
	{
		for(int i=0; i<x.length; i++)
		{
			System.out.println(x[i]);
		
		}
	}
	static String input()
	{
		Scanner oj=new Scanner(System.in);
		System.out.println("Enter your name to check your friend or not");
		String find=oj.nextLine();
		return find;
	
	
	}
	static Boolean check(String x[],String value)
	{
	
		Boolean con=false;	
		for(int i=0; i<x.length; i++)
		{
			value=value.toUpperCase();
			x[i]=x[i].toUpperCase();
			if(x[i].equals(value))
			{
				con=true;
				//System.out.println(array[i]);
				break;
			}
			
			//con=false;
		}
		return con;
	
	
	}
	public static void main(String args[])
	{
		Scanner oj=new Scanner(System.in);
		Boolean con=false;
		String array[]={"Velu","Raj","Kumar"};
		System.out.println("My Friend List:  ");
		display(array);
		String bup=input();
		//System.out.println(bup2);
		//check(array,bup);
		con=check(array,bup);
		//System.out.println(con);
		if(con)
		{
			System.out.println(bup+" Your my friend ");
		}
		else
		{
		
			System.out.println(bup+" Your not my friend list");
		}	
	}
}
