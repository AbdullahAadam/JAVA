import Firstpk.Pa;
class Pack
{
	public static void main(String args[])
	{
		Pa oj=new Pa();
		oj.display();
	
	
	
	
	}





}
