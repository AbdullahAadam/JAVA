import java.util.Scanner;
class Fib
{
	public static void main(String args[])
	{
		Scanner o=new Scanner(System.in);
		System.out.println("Enter the Value of terms..");
		int x=o.nextInt();
		int f1,f2,f;
		f0=-1;
		f1=1;
		f=0;
		do
		{
			f=f0+f1;
			System.out.println(f);
			f0=f1;
			f1=f;
			
		
		
		
		
		}while();	
	
	
	
	
	}




}
