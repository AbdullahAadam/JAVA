class Es
{
	public static void main(String args[])
	{
		//\n
		//System.out.println("HI \nWELCOME TO THE REAL WORLD");
		
		//\t
		//System.out.println("HI \t Welcome to the real world");
		
		//\'
		//System.out.println("I\'m Abdullah ");
		
		//\"
		//System.out.println("Im \"Abdullah\"");
		
		//lash
		//System.out.println("ore wa Kai\\");
		
		//b
		//System.out.println("LETS GO TO TTHE REA\bL WORLD BRO");
		
		//\r
		System.out.println("WELCOME TO WELCOMEDSFDSF TO \rTHE REAL WORLD");
		
		//\f
		System.out.println("WELCOME TO \f THE REAL WORLD");
	
	
	}



}
