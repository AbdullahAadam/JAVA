import java.util.Scanner;
class Sq
{
	public static void main(String args[])
	{
		Scanner oj=new Scanner(System.in);
		//System.out.println("Enter The")
		/*for(int i=5; i>=0; i--)
		{
			
			
				//System.out.print("\t");
				for(int j=1; j<=i; j++)
				{
					System.out.print("\t*");
				}
				System.out.println();
			
		}*/
		//int a=1;
		/*for(int z=5; z>=a; z--)
		{
			System.out.print("\t");
			for(int i=1; i<=5; i++)
			{
				for(int j=1; j<=i; j++)
				{
					System.out.print(i);
			
				}
			System.out.println();
			}
			a++;
		}*/
		for(int i=1; i<=5; i++)
		{
			for(int z=4; z>=i; z--)
			{
				System.out.print("  ");
			}
			//System.out.print("\t");
			for(int j=1; j<=i; j++)
			{
				
				System.out.print("  "+i+"  ");
				//System.out.println();
			}
			System.out.println();
		}
		
	}
}
