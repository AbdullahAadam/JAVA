import java.util.Scanner;
class Account
{
	int Bal=1000;
	//int BALANCE=1000;
	String aname,atype;
	int anum,wit,dep;
	void set(String name,int num, String type)
	{
		aname=name;
		anum=num;
		atype=type;
	}
	void dep(int dval)
	{
		dep=dval;
		Bal=Bal+dep;
	}
	void with(int wval)
	{
		wit=wval;
		Bal=Bal-wval;
		//return Bal;
	}
	void display()
	{
		System.out.println("Your name is "+aname);
		//System.out.println("BALANCE: "+BALANCE);
		System.out.println("DEPOSITE AMOUNT: "+dep);
		System.out.println("WITHDRAW AMOUNT: "+wit);
		System.out.println("NOW BALANCE: "+Bal);
	}
}
class Bank
{
	public static void main(String args[])
	{
		Account ac=new Account();
		int BALANCE=ac.Bal;
		Scanner oj=new Scanner(System.in);
		System.out.println("Enter Your name: ");
		String name=oj.nextLine();
		System.out.println("Enter your Account Number: ");
		String sanum=oj.nextLine();
		int num=Integer.parseInt(sanum);
		System.out.println("Enter your Type Account ");
		String atype=oj.nextLine();
		System.out.println("Enter your Cash Amount to Depostie: ");
		String saval=oj.nextLine();
		int val=Integer.parseInt(saval);
		System.out.println("Enter your AMount to WithDraw: ");
		String sawit=oj.nextLine();
		int wit=Integer.parseInt(sawit);
		//Account ac=new Account();
		ac.set(name,num,atype);
		ac.dep(val);
		if(wit<ac.Bal)
		{
			System.out.println("PERIVOIS BALANCE: "+BALANCE);
			ac.with(wit);
			ac.display();
		}
		else
		{
			System.out.println("Sorry insufficient Amount: ");
			System.out.println("YOUR BALANCE IS "+ac.Bal);
		}
	}
}
