import java.util.Scanner;
class Account
{
	int Bal=1000;
	//int BALANCE=1000;
	String aname,atype;
	int anum,wit,dep;
	void set(String name,int num, String type)
	{
		this.aname=name;
		this.anum=num;
		this.atype=type;
	}
	void dep(int dval)
	{
		this.dep=dval;
		this.Bal=Bal+dep;
	}
	void with(int wval)
	{
		wit=wval;
		this.Bal=Bal-wval;
		//return Bal;
	}
	void display()
	{
		System.out.println("Your name is "+aname);
		//System.out.println("BALANCE: "+BALANCE);
		System.out.println("DEPOSITE AMOUNT: "+dep);
		System.out.println("WITHDRAW AMOUNT: "+wit);
		System.out.println("NOW BALANCE: "+Bal);
	}
}
class Abank
{
	public static void main(String args[])
	{
		
		Scanner oj=new Scanner(System.in);
		//Account ac[];
		System.out.println("Enter number");
		String sau=oj.nextLine();
		int au=Integer.parseInt(sau);
		Account[] ac=new Account[au];
		//Account ac[]=new Account[];
		//for(int i=0; i<ac.length; i++)
		for(int i=0; i<au; i++)
		{
			ac[i]=new Account();
			//System.out.println(ac.length);
			System.out.println("USER"+(i+1));
			//int BALANCE=ac[i].Bal;
			//Scanner oj=new Scanner(System.in);
			System.out.println("Enter Your name: ");
			String name=oj.nextLine();
			System.out.println("Enter your Account Number: ");
			String sanum=oj.nextLine();
			int num=Integer.parseInt(sanum);
			System.out.println("Enter your Type Account ");
			String atype=oj.nextLine();
			/*System.out.println("Enter your Cash Amount to Depostie: ");
			String saval=oj.nextLine();
			int val=Integer.parseInt(saval);
			System.out.println("Enter your AMount to WithDraw: ");
			String sawit=oj.nextLine();
			int wit=Integer.parseInt(sawit);*/
			ac[i].set(name,num,atype);
			//ac[i].dep(val);
		}
		System.out.println("Choose It ");
		String scho=oj.nextLine();
		int cho=Integer.parseInt(scho);
		if(au>=cho)
		{
			do
			{
				cho--;
				System.out.println("Enter your Cash Amount to Depostie: ");
				String saval=oj.nextLine();
				int val=Integer.parseInt(saval);
				ac[cho].dep(val);
				System.out.println("Enter your AMount to WithDraw: ");
				String sawit=oj.nextLine();
				int wit=Integer.parseInt(sawit);
				if(wit<ac[cho].Bal)
				{
					//System.out.println("PERIVOIS BALANCE: "+BALANCE);
					ac[cho].with(wit);
					ac[cho].display();
				}
				else
				{
					System.out.println("Sorry insufficient Amount: ");
					System.out.println("YOUR BALANCE IS "+ac[cho].Bal);
				}
				break;
			}while(false);
		}
		else
			System.out.println("Invalid Choice");	
	}
}
