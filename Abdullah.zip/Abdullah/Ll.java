import java.util.Collections;
import java.util.*;
class Ll
{
	public static void main(String args[])
	{
		Scanner oj=new Scanner(System.in);
		ArrayList ar=new ArrayList();
		boolean lp=true;
		System.out.println(ar);
		System.out.println("See the Choice");
		while(lp)
		{
			System.out.println("1. To Insert");
			System.out.println("2. To Remove");
			System.out.println("3. To Edit");
			System.out.println("4. To Sort");
			System.out.println("5. To Search ");
			System.out.println("6. Exit");
			System.out.println("Enter the Your choice");
			String cho=oj.nextLine();
			switch(cho)
			{
				case "1":
					System.out.println("Your Entered 1...");
					System.out.println("It\'s means You want to Insert Element ");
					System.out.println("Enter Your Element");
					String val=oj.nextLine();
					//val=Integer.parseInt(val);
					Integer.parseInt(val);
					ar.add(val);
					System.out.println("Successfully Inserted.....");
					System.out.println(ar);
					break;
				
				case "2":
				
					System.out.println("Your Entered 2.....");
					System.out.println("It\'s means You want to Remove the Element");
					System.out.println("Enter your Element to Remove");
					String rm=oj.nextLine();
					//rm=Integer.parseInt(rm);
					Integer.parseInt(rm);
					ar.remove(rm);
					System.out.println(rm+" Element Successfully remove see");
					System.out.println(ar);
					break;
					
				case "3":
					System.out.println("You Entered 3...");
					System.out.println("You wanna to Update the Element");
					System.out.println(ar);
					System.out.println("Enter the list Index number");
					String in=oj.nextLine();
					int in2=Integer.parseInt(in);
					in2--;
					System.out.println("Enter your Value to update ");
					String name=oj.nextLine();
					Integer.parseInt(name);
					ar.set(in2,name);
					System.out.println("Successfully Updated");
					System.out.println(ar);
					break;
				
				case "4":
					System.out.println("You Entered 4th Choice..");
					System.out.println("There two types of Choice ");
					System.out.println("1. Ascending");
					System.out.println("2. Decending");
					System.out.println("Enter your choice for shorting");
					String scho=oj.nextLine();
					//if(scho=="1")
					//{//
						
						//String ar;
						Collections.sort(ar);
						System.out.println(ar);
					
					//}
					//else if(scho=="2")
					//{//
						Collections.sort(ar,Collections.reverseOrder());
						System.out.println(ar);
						
					
					//}//
					/*else
					{
						System.out.println("Invalid Choice");
					
					}*/
					break;
					
				case "5":
					System.out.println("You Entered 5th Choice");
					System.out.println(ar);
					System.out.println("Enter  what  Element want to secrch..");
					String fin=oj.nextLine();
					Integer.parseInt(fin);
					if(ar.contains(fin))
					{
						System.out.println("Yes Elemnt is have");
						int len=ar.size();
						int j=ar.size();
						j-- ;
						int count=0;	
						for(int i=0; i<len; i++)
						{
							if(ar.get(i)==ar.get(j))
								count++;
							j--;
						}
						System.out.println("No of count is"+count);
					}
					else
					{
						System.out.println("No Element is havae");
					}
					break;
				case "6":
					lp=false;
					break;
				default:
					System.out.println("Undefind Choice plz Enter correct Choice");
					
				
			}
		}		
	}	
}
