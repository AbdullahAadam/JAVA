package Firstpk;
public class Testpk
{
	void display()
	{
		System.out.println("Printtin Firstpk in Testpk class");
	}
} 
