import java.util.Scanner;
class Con
{
	String name;
	int age;
	public  Con()
	{
		name="Unknown";
		age=0;
	
	}
	public  Con(String name,int age)
	{
		name=name;
		age=age;
		System.out.println("your name is "+name+" and your age is "+age);
	}
	public static void main(String args[])
	{
		Scanner oj=new Scanner(System.in);
		System.out.println("Enter Your Name:...");
		String x=oj.nextLine();
		System.out.println("Enter Your Age....");
		int num=oj.nextInt();
		//Con det=new Con();
		//System.out.println(det.name+""+det.age);
		Con det2=new Con(x,num);
		System.out.println(det2.name+""+det2.age);
	
	
	
	}



}
