import java.util.Scanner;
class Fun
{
	static int printNum(int x)
	{
		for(int i=0; i<=x; i++)
			System.out.println(i);
		return 10;
	}
	public static void main(String args[])
	{
		Scanner obj=new Scanner(System.in);
		System.out.println("Enter the Values: ");
		int v=obj.nextInt();
		int values=printNum(v);
		System.out.println("Enter the 2nd Values: ");
		int v2=obj.nextInt();
		System.out.println(printNum(v2));
		System.out.println(values +" Returen values");
		
	
	
	
	
	}



}
