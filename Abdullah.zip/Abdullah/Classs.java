import java.util.Scanner;
class Student
{
	String name;
	int age;
	int rollnum;
	public void set(String name,int age,int rollnum)
	{
		this.name=name;
		this.age=age;
		this.rollnum=rollnum;
	}
	public void display()
	{
		System.out.println("Your name is "+name);
		System.out.println("Your age is "+age);
		System.out.println("Your Roll Number is "+rollnum);
	}
}
class Classs
{
	public static void main(String args[])
	{
		Scanner oj=new Scanner(System.in);
		System.out.println("Enter our name...");
		String name=oj.nextLine();
		System.out.println("Enter our age...");
		int age=oj.nextInt();
		System.out.println("Enter our Roll Number...");
		int rn=oj.nextInt();
		Student ok=new Student();
		ok.set(name,age,rn);
		ok.display();
		
	}
}
