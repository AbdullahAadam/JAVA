import java.util.Scanner;
class Check
{
	public static void main(String args[])
	{
		
		/*int x=a.length;
		int i,sum;
		sum=0;
		for(i=0; i<x; i++)
		{
			sum=sum+Integer.parseInt(a[i]);	
		}
		System.out.println("Total values: "+sum);
		
		//System.out.println(30+46+" is the Sum "+(2+3));*/
		Scanner sc=new Scanner(System.in);
		Boolean con=true;
		while(con)
		{
		System.out.println("We hava");
		System.out.println("1.Add");
		System.out.println("2.Multiplication");
		System.out.println("3.Min to Sec");
		System.out.println("4.celcius to farenheit");
		System.out.println("5.Exit");
		System.out.println("Enter your choice: ");
		int cho =sc.nextInt();
		switch(cho)
		{
			case 1:
			{
				System.out.println("You Enter the 1 Its is Addtion");
				int result;
				System.out.println("Enter the a value: ");
				int a=sc.nextInt();
				System.out.println("Enter the b value: ");
				int b=sc.nextInt();
				result=a + b;
				System.out.println("Result of two values is: "+result);
				break;
			}
			case 2:
			{
				System.out.println("You Enter the 2 Its is Multiplication");
				int result;
				System.out.println("Enter the a value: ");
				int a=sc.nextInt();
				System.out.println("Enter the b value: ");
				int b=sc.nextInt();
				result=a * b;
				System.out.println("Result of Multiplaction of two values 						is:"+result);
		
				break;
			}
			case 3:
			{
				System.out.println("You Enter the 3 Its is Min to Sec");
				int sec;
				System.out.println("Enter the Minutes: ");
				int min=sc.nextInt();
				sec=min * 60;
				System.out.println(min+"min is  = to "+sec +" Seconds");
				break;
			}
			case 4:
			{
				System.out.println("You Enter the 4 Its is celcius to farenheit");
				System.out.println("Enter the Celcius degree");
				float deg = sc.nextFloat();
				System.out.println(deg);
				float f,f2;
				f=(deg * 1.8f);
				f2=f+32;
				System.out.println(deg+" celcius is convert into Farenheit degree is "+f2);
				System.out.println(deg+" celcius is convert into Farenheit degree is "+f2);
				break;
			
			}
			case 5:
			{
				con=false;
				break;
			
			}
			default:
			{
				System.out.println("Out of Choice");
			}
		
		}
		if(con==false)
			break;
		}		
		
	}
}

