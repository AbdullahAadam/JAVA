import java.lang.Exception;
import java.util.Scanner;
class Mymsg extends Exception
{
	Mymsg(String s)
	{
		super(s);
	}
}

class Th
{
	public static void main(String args[])
	{
		Scanner oj=new Scanner(System.in);
		System.out.println("Enter the 1st Value: ");
		int a=oj.nextInt();
		System.out.println("Enter the 2nd Value:");
		int b=oj.nextInt();
		//int a=10;
		//int b=100;
		try{
			if(a==b)
			{
				System.out.println("They are Equal");
			}
			else
			{
				throw new Mymsg("No its not Equal  number..");
			}
		}
		catch(Exception e)
		{
		
			System.out.println("COMMM Error");
		
		}
		catch(Mymsg e)
		{
			System.out.println("ocuure Error");
			System.out.println(e.getMessage());
		}
		//catch()
		finally
		{
			System.out.println("Program Successfully Finished");
		}
	
	}
}
