class Up
{
	String name="Kumar";
	void setup()
	{
		this.name="Kai";	
	
	}
	void displayup()
	{
		System.out.println(name);
	}
}
class Down extends Up
{
	void display()
	{
		System.out.println(name);
	}
}
class In
{
	public static void main(String args[])
	{
		Down oj=new Down();
		
		oj.display();
		oj.setup();
		oj.displayup();	
	}
}
