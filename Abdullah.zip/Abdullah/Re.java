import java.util.Scanner;
class Re
{
	public  static void main(String args[])
	{
		Scanner oj=new Scanner(System.in);
		String val="Dhatchan Academy is our academy";
		System.out.println(val);
		System.out.println("we hava \"TWO\" choice...");
		System.out.println("1..Replace specfic choice...");
		System.out.println("2...Replace all...");
		System.out.println("Now..Enter your choice...");
		String cho=oj.nextLine();
		if(cho.equals("1"))
		{
			System.out.println("Your Entered 1..");
			System.out.println("Enter the your String...");
			String sstr=oj.nextLine();
			System.out.println("Your Entered "+sstr);
			System.out.println("Now Enter the Replace String....");
			//System.out.println("Replace String is "+ustr);
			String rstr=oj.nextLine();
			System.out.println("Replace String is "+rstr);
			//Boolean check=val.equalsIgnoreCase(ustr);
			boolean check=val.contains(sstr);
			//System.out.println(check);
			/*if(.equals("is"))
			{
				System.out.println("try");
			}*/
			if(check)
			{
				System.out.println(val.replace(sstr,rstr));
				//System.out.println("dfsfda");
			}
			else
			{
				System.out.println("Invalid Input...");
				
			}
		}
		if(cho.equals("2"))
		{
			System.out.println("Your Entered 2..");
			System.out.println("Enter  your String to Replalce All...");
			String astr=oj.nextLine();
			System.out.println(val+"Replace into all.. "+""+val.replaceAll(val,astr));
		
		}
			
			
	}		
	
}
