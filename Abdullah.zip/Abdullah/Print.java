class Print
{
	public static void main(String args[])
	{
		//String name="Abdullah";
		System.out.println(System.out.println("Abdullah"));;
	
	
	}



}
