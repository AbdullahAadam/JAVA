import java.util.*;
import java.io.*;
import java.util.Scanner;
class Tr extends Thread
{
	 public void run()
	{
		//Scanner oj=new Scanner(System.in);
		//System.out.println("Enter what your  tables to print");
		//int x=oj.nextInt();
		//System.out.println("Enter who many wants to print");
		//int y=oj.nextInt();
		try{
		for(int i=1;i<=10; i++)
		{
			int an=i*5;
			System.out.println(i+"*"+5+"="+an);
			System.out.println("dfasdf");
			sleep(100);
		}
		}
		catch(InterruptedException e)
		{
			System.out.println("sleeping");
		}
	
	
	}
	public static void main(String args[])
	{
		Scanner oj=new Scanner(System.in);
		Tr oj1=new Tr();
		Tr oj2=new Tr();
		/*System.out.println("Enter what your  tables to print");
		int x=oj.nextInt();
		System.out.println("Enter who many wants to print");
		int y=oj.nextInt();*/
		long stime=System.nanoTime();
		System.out.println("Strating Time "+stime);
		try{
		oj1.start();
		oj2.start();
		oj1.join();
		oj2.join();
		}
		catch(InterruptedException e)
		{
			System.out.println("Kkk");
		
		}
		long etime=System.nanoTime();
		//long etime=System.nanoTime();
		//System.out.println("Ending Time"+etime);
		long time=etime-stime;
		System.out.println("Time Taken"+time);
		//System.out.println("Strating Time "+stime);
		//long etime2=System.nanoTime();
		//System.out.println("Ending Time"+etime2);
		//long time2=etime2-stime2;
		//System.out.println("Time Taken"+time2);
		
		
	}

}
