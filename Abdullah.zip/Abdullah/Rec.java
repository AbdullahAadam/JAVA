import java.util.Scanner;
class Rec
{
	static int pro(int x ,int i)
	{
		if(x==0)
		{
			System.out.println("0");
			return 0;
		}
		if(i<=x)
		{
			System.out.println(i);
			i++;
			pro(x,i);
			return i;
		}
		return 0;
			
	}
	public static void main(String args[])
	{
		System.out.println("Enter the number want to Print: ");
		Scanner oj=new Scanner(System.in);
		int val=oj.nextInt();
		pro(val,1);
	}
}
