public class Student
{
 String name;
 int rollno;
 public Student(String n, int r)
 {
  name=n;
  rollno=r;
 }
 public static void main(String args[])
 {
   Student mydet=new Student("SRI",1);
   System.out.println(mydet.name+" "+mydet.rollno);
   //name="Abdullah";
   System.out.println(mydet.name);
   Student mydet2=new Student("Kumar",2);
   //Student mydet3=new Student("Adam",3);
   System.out.println(mydet2.name+" "+mydet2.rollno);
   Student mydet3=new Student("Adam",3);
   System.out.println(mydet3.name+" "+mydet3.rollno);
 }
}  
