package Firstpk;
public class Pa
{
	public void display()
	{
		System.out.println("Prining Package pk");
	}
}
