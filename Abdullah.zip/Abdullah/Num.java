class Num
{
	public static void main(String args[])
	{
		int count=0;
		int incount=0;
		for(int i=0; i<args.length; i++)
		{
			try{
				int value=Integer.parseInt(args[i]);
				System.out.println("Valid are: "+args[i]);
				count++;
			}
			catch(NumberFormatException e)
			{
				incount++;
				//System.out.println("Invalid.... ");
				System.out.println("Invalid are: "+args[i]);
			}
			//count++;
		}
		System.out.println("Correct are: "+count);
		System.out.println("Not Correct are: "+incount);
	}
}
	
	
	
	
